var config ={
appId : "AIzaSyAlrJQN1j24PDIUDgQT5bvV0uRe55yzN44",
databaseRoot :"comapnies",
authDomain:"mynodetest-38588.firebaseapp.com",
databaseURL:"https://mynodetest-38588.firebaseio.com",
storageBucket:"mynodetest-38588.appspot.com",
localStorageUserApiKey:"firebase:authUser:AIzaSyAlrJQN1j24PDIUDgQT5bvV0uRe55yzN44:[DEFAULT]"
}


export default config;