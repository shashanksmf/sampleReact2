import initSkycon from '../Common/skycons';

export default () => {
    $('[data-skycon]').each(initSkycon);
}