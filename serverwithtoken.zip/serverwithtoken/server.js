var path = require('path');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var CryptoJS = require("crypto-js");

/*var nodemailer = require('nodemailer');*/

app.use(express.static(path.join('dist')));

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

/* app.use(__dirname +'/dist/', function (req, res) {
        console.log("login all");
        res.sendFile(__dirname +'/dist/index.html');
    }); */

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});


app.post('/createToken',function(req,res){
    var tokenId = req.body.userToken;
    var currentTime = req.body.currentTime;
   var ciphertext = CryptoJS.AES.encrypt(tokenId, 'mySecretKey');
   
    //var splitEnToken = deciphertext.split("-");
    //console.log("deciphertext Token : ",ciphertext);
    res.send(ciphertext.toString());
    
})

app.post('/validateToken',function(req,res){
    var tokenId = req.body.userToken;
    var currentTime = req.body.currentTime;
 //   console.log("tokenId: ",tokenId);
    var deciphertext  = CryptoJS.AES.decrypt(tokenId.toString(), 'mySecretKey');
    console.log("deciphertext: ",deciphertext.toString());
    
    res.send(deciphertext.toString());
    
})


var port = 3099;

app.listen(3099, function () {
  console.log('Example app listening on port '+port+'!');
});