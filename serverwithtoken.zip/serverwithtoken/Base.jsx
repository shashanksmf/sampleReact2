import React from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';

import Header from './Header'
import Sidebar from './Sidebar'
import Offsidebar from './Offsidebar'
import Footer from './Footer'
import { Router, Route, Link, hashHistory, browserHistory, IndexRoute } from 'react-router';

class Base extends React.Component {
    constructor(){
        super();
        var getEnToken = localStorage.getItem('userEnToken');
        
        if(getEnToken != undefined && getEnToken.length > 0){
            $.ajax({
          url: 'http://localhost:3099/validateToken',
          dataType: "json",
          data:{'userToken':getEnToken+'-'+new Date().toISOString(),'currentTime':new Date().toISOString()},
          type: 'POST',
          cache: false,
          success: function(isSuccess) {
          console.log("isSuccessdata :",isSuccess);
          var enToken = isSuccess.responseText;        
          }.bind(this),
          error: function(xhr, status, err) {
           console.log("errro base",xhr,status,err);
          }.bind(this)
        });        
      }
          
    }

    render() {

        // Animations supported
        //      'rag-fadeIn'
        //      'rag-fadeInUp'
        //      'rag-fadeInDown'
        //      'rag-fadeInRight'
        //      'rag-fadeInLeft'
        //      'rag-fadeInUpBig'
        //      'rag-fadeInDownBig'
        //      'rag-fadeInRightBig'
        //      'rag-fadeInLeftBig'
        //      'rag-zoomBackDown'

        const animationName = 'rag-fadeIn'
        

        return (
            <div className="wrapper">
                <Header />

                <Sidebar />

                <Offsidebar />

                <ReactCSSTransitionGroup
                  component="section"
                  transitionName={animationName}
                  transitionEnterTimeout={500}
                  transitionLeaveTimeout={500}
                >
                  {React.cloneElement(this.props.children, {
                    key: Math.random()
                  })}
                </ReactCSSTransitionGroup>

                <Footer />
            </div>
        );
    }

}

export default Base;
