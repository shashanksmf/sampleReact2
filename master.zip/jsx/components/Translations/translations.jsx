//create a function which contains global variables

var register_error_msg = "123";